
import java.util.ArrayList;
import java.util.Collections;

public class Exercise19_09 {
  public static void main(String[] args) {
	  
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(14);
    list.add(24);
    list.add(4);
    list.add(42);
    list.add(5);
    list.add(22);
    
    Exercise19_09.<Integer>sort(list);
    
    System.out.println("Sorted ArrayList: " + list);
    
    ArrayList<String> strings = new ArrayList<>();
    strings.add("banana");
    strings.add("apple");
    strings.add("orange");
    
    sort(strings);
    
    System.out.print("Sorted arrayList: " + strings);
  }
  public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
	  Collections.sort(list);
  }
}
