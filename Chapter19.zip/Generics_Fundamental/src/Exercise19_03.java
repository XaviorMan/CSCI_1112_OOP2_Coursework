import java.util.ArrayList;
import java.util.Random;

public class Exercise19_03 {
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            ArrayList<Integer> list = generateRandomIntegers(5, 100);

            System.out.println("Original List: " + list);

            ArrayList<Integer> newList = removeDuplicates(list);

            System.out.println("New List without Duplicates: " + newList);
            System.out.println("------------------------------");
        }
    }

    public static ArrayList<Integer> generateRandomIntegers(int count, int range) {
        ArrayList<Integer> randomList = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            randomList.add(random.nextInt(range) + 1); // Generating integers from 1 to range
        }

        return randomList;
    }

    public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
        ArrayList<E> result = new ArrayList<>();

        for (E element : list) {
            if (!result.contains(element)) {
                result.add(element);
            } else {
                System.out.println("Removed duplicate element: " + element);
            }
        }

        return result;
    }
}
