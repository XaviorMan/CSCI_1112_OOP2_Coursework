import org.junit.Test;
import java.util.ArrayList;  // Import ArrayList
import static org.junit.Assert.*;

public class Exercise19_03Test {

    @Test
    public void testDuplicateRemoval() {
        int totalRemovedDuplicates = 0;

        for (int i = 0; i < 100; i++) {
            ArrayList<Integer> list = Exercise19_03.generateRandomIntegers(5, 100);

            ArrayList<Integer> newList = Exercise19_03.removeDuplicates(list);

            totalRemovedDuplicates += countRemovedDuplicates(list, newList);
        }

        System.out.println("Total numbers removed more than once: " + totalRemovedDuplicates);

        // You can add assertions if needed
        // For example, assert that the totalRemovedDuplicates is less than some threshold.
        // assertEquals(expectedValue, actualValue);
    }

    private int countRemovedDuplicates(ArrayList<Integer> originalList, ArrayList<Integer> newList) {
        int count = 0;

        for (Integer element : originalList) {
            if (originalList.lastIndexOf(element) != originalList.indexOf(element)) {
                count++;
            }
        }

        return count;
    }
}
