import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.layout.StackPane;

public class CountdownStopwatch extends Application {

    private TextField secondsInput;
    private Label timerLabel;
    private int remainingSeconds;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Countdown Stopwatch");

        Text instructionText = new Text("How many seconds?");
        
        secondsInput = new TextField();
        secondsInput.setPromptText("Enter seconds");
        secondsInput.setOnAction(e -> startCountdown(primaryStage));

        timerLabel = new Label();
        
        VBox inputLayout = new VBox(10);
        inputLayout.setAlignment(Pos.CENTER);
        inputLayout.getChildren().addAll(instructionText, secondsInput);

        StackPane mainLayout = new StackPane();
        mainLayout.getChildren().add(inputLayout);

        Scene scene = new Scene(mainLayout, 300, 200);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    private void startCountdown(Stage primaryStage) {
        try {
            remainingSeconds = Integer.parseInt(secondsInput.getText());
            if (remainingSeconds <= 0) {
                return;
            }

            VBox countdownLayout = new VBox(10);
            countdownLayout.setAlignment(Pos.CENTER);
            countdownLayout.getChildren().add(timerLabel);

            StackPane newLayout = new StackPane();
            newLayout.getChildren().add(countdownLayout);

            Scene newScene = new Scene(newLayout, 300, 200);
            primaryStage.setScene(newScene);

            javafx.animation.Timeline timeline = new javafx.animation.Timeline(
                    new javafx.animation.KeyFrame(Duration.seconds(1), event -> {
                        remainingSeconds--;
                        updateTimerLabel();
                        if (remainingSeconds == 0) {
                            playMusic();
                        }
                    }));
            timeline.setCycleCount(remainingSeconds);
            timeline.play();

        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number of seconds.");
        }
    }

    private void updateTimerLabel() {
        timerLabel.setText(Integer.toString(remainingSeconds));
        if (remainingSeconds <= 5) {
            timerLabel.setStyle("-fx-text-fill: red; -fx-font-size: 24;");
        } else {
        	timerLabel.setStyle("-fx-text-fill: black; -fx-font-size: 18");
        }
    }

    private void playMusic() {
        String musicFilePath = "https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3";
        Media sound = new Media(musicFilePath);
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
}
