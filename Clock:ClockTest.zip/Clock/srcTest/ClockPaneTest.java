import java.util.Random;

public class ClockPaneTest {
    public static void main(String[] args) {
        ClockPane clock = new ClockPane();

        // Generate random values for hour and minute
        Random random = new Random();
        int randomHour = random.nextInt(12); // Random hour between 0 and 11
        int randomMinute = (random.nextBoolean()) ? 0 : 30; // Random minute, either 0 or 30

        clock.setHour(randomHour);
        clock.setMinute(randomMinute);
        clock.setHourHandVisible(true);
        clock.setMinuteHandVisible(true);
        clock.setSecondHandVisible(false);

        clock.displayTime();
    }
}
