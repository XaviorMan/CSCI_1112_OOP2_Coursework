import javafx.animation.Interpolator;
import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PentagonAnimation extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Pentagon's corner coordinates
        Double[] pentagonPoints = {
                400.0, 100.0,
                600.0, 300.0,
                550.0, 500.0,
                350.0, 500.0,
                300.0, 300.0
        };

        // Create a polygon for the Pentagon
        Polygon pentagon = new Polygon();
        pentagon.getPoints().addAll(pentagonPoints);
        pentagon.setFill(Color.RED);

        // Create a rectangle
        Rectangle rectangle = new Rectangle(pentagonPoints[0], pentagonPoints[1], 50, 50);
        rectangle.setFill(Color.BLUE);

        // Create a path transition
        PathTransition pathTransition = new PathTransition();
        pathTransition.setNode(rectangle);
        pathTransition.setPath(pentagon);
        pathTransition.setInterpolator(Interpolator.LINEAR);
        pathTransition.setCycleCount(PathTransition.INDEFINITE); // Loop indefinitely
        pathTransition.setDuration(Duration.seconds(5));

        Group root = new Group(pentagon, rectangle);

        // Create a scene
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Pentagon Animation");
        primaryStage.show();

        // Handle mouse click events to pause animation
        scene.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                if (pathTransition.getStatus() == PathTransition.Status.RUNNING) {
                    pathTransition.pause();
                } else {
                    pathTransition.play();
                }
            }
        });

        // Start the animation
        pathTransition.play();
    }
}
