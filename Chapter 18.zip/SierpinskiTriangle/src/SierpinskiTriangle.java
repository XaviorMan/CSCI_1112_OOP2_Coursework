import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;

public class SierpinskiTriangle extends Application {
    private int order = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        SierpinskiTrianglePane trianglePane = new SierpinskiTrianglePane();

        Button btnIncrease = new Button("+");
        Button btnDecrease = new Button("-");

        btnIncrease.setOnAction(e -> {
            trianglePane.increaseOrder();
        });

        btnDecrease.setOnAction(e -> {
            trianglePane.decreaseOrder();
        });

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(trianglePane);
        borderPane.setBottom(btnIncrease);
        borderPane.setTop(btnDecrease);

        Scene scene = new Scene(borderPane, 400, 400);
        primaryStage.setTitle("Sierpinski Triangle");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    static class SierpinskiTrianglePane extends Pane {
        private int order = 0;

        public void setOrder(int order) {
            this.order = order;
            paint();
        }

        public void increaseOrder() {
            setOrder(order + 1);
        }

        public void decreaseOrder() {
            if (order > 0) {
                setOrder(order - 1);
            }
        }

        SierpinskiTrianglePane() {
        }

        protected void paint() {
        	
            double x1 = getWidth() / 2;
            double y1 = 10;
            double x2 = 10;
            double y2 = getHeight() - 10;
            double x3 = getWidth() - 10;
            double y3 = getHeight() - 10;

            this.getChildren().clear();

            displayTriangles(order, x1, y1, x2, y2, x3, y3);
        }

        private void displayTriangles(int order, double x1, double y1, double x2, double y2, double x3, double y3) {
            if (order == 0) {
                // Draw a triangle
                Polygon triangle = new Polygon();
                triangle.getPoints().addAll(x1, y1, x2, y2, x3, y3);
                triangle.setStroke(Color.BLACK);
                triangle.setFill(Color.WHITE);

                this.getChildren().add(triangle);
            } else {

                double midX1 = (x1 + x2) / 2;
                double midY1 = (y1 + y2) / 2;
                double midX2 = (x2 + x3) / 2;
                double midY2 = (y2 + y3) / 2;
                double midX3 = (x1 + x3) / 2;
                double midY3 = (y1 + y3) / 2;

                displayTriangles(order - 1, x1, y1, midX1, midY1, midX3, midY3);
                displayTriangles(order - 1, midX1, midY1, x2, y2, midX2, midY2);
                displayTriangles(order - 1, midX3, midY3, midX2, midY2, x3, y3);
            }
        }
    }
}
