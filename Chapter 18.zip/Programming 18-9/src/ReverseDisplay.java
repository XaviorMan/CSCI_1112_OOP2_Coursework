

public class ReverseDisplay {
	
    public static void main(String[] args) {
        String inputString = "Hello, World!";
        reverseDisplay(inputString);
    }

    public static void reverseDisplay(String value) {
        reverseDisplayHelper(value, value.length() - 1);
    }

    private static void reverseDisplayHelper(String value, int index) {
    	
        if (index < 0) {
            return;
        }

        System.out.print(value.charAt(index));

        reverseDisplayHelper(value, index - 1);
    }
}
