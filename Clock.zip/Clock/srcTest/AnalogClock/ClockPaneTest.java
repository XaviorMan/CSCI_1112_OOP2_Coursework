package AnalogClock;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ClockPaneTest extends Application {
    @Override
    public void start(Stage primaryStage) {
    	
        int randomHour = (int) (Math.random() * 12);
        int randomMinute = (int) (Math.random() * 2) * 30;

        ClockPane clockPane = new ClockPane(randomHour, randomMinute, 0);
        clockPane.setSecondHandVisible(false);

        Scene scene = new Scene(clockPane, 300, 300);
        primaryStage.setTitle("Analog Clock Test");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
