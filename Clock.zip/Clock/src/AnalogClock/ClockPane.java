package AnalogClock;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

public class ClockPane extends Pane {
    private int hour;
    private int minute;
    private int second;
    private boolean hourHandVisible;
    private boolean minuteHandVisible;
    private boolean secondHandVisible;
    private int clockSize;

    public ClockPane() {
        initialize();
        setCurrentTime();
        displayAnalogClock();
    }

    public ClockPane(int hour, int minute, int second) {
        initialize();
        this.hour = hour;
        this.minute = minute;
        this.second = second;
        setCurrentTime();
        displayAnalogClock();
    }

    private void initialize() {
        setClockSize(200);  // Default clock size
        setHourHandVisible(true);
        setMinuteHandVisible(true);
        setSecondHandVisible(true);
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
        displayAnalogClock();
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
        displayAnalogClock();
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) {
        this.second = second;
        displayAnalogClock();
    }

    public boolean isHourHandVisible() {
        return hourHandVisible;
    }

    public void setHourHandVisible(boolean visible) {
        this.hourHandVisible = visible;
        displayAnalogClock();
    }

    public boolean isMinuteHandVisible() {
        return minuteHandVisible;
    }

    public void setMinuteHandVisible(boolean visible) {
        this.minuteHandVisible = visible;
        displayAnalogClock();
    }

    public boolean isSecondHandVisible() {
        return secondHandVisible;
    }

    public void setSecondHandVisible(boolean visible) {
        this.secondHandVisible = visible;
        displayAnalogClock();
    }

    public int getClockSize() {
        return clockSize;
    }

    public void setClockSize(int size) {
        this.clockSize = size;
        displayAnalogClock();
    }

    public void displayAnalogClock() {
        getChildren().clear(); 

        // Draw clock face
        Circle clockFace = new Circle(getClockSize() / 2, getClockSize() / 2, getClockSize() / 2 - 10);
        clockFace.setFill(Color.WHITE);
        clockFace.setStroke(Color.BLACK);
        getChildren().add(clockFace);

        // Draw clock hands
        if (isHourHandVisible()) drawClockHand(getHour(), getClockSize() / 4, Color.BLACK, 5);
        if (isMinuteHandVisible()) drawClockHand(getMinute(), getClockSize() / 3, Color.BLUE, 3);
        if (isSecondHandVisible()) drawClockHand(getSecond(), getClockSize() / 2.5, Color.RED, 1);
    }

    private void drawClockHand(int timeUnit, double length, Color color, int strokeWidth) {
        double angle = (90 - timeUnit % 12 * 30) % 360;
        Line hand = new Line(getClockSize() / 2, getClockSize() / 2,
                getClockSize() / 2 + length * Math.cos(Math.toRadians(angle)),
                getClockSize() / 2 - length * Math.sin(Math.toRadians(angle)));
        hand.setStroke(color);
        hand.setStrokeWidth(strokeWidth);
        getChildren().add(hand);
    }

    private void setCurrentTime() {
    	
        // Set current time if not provided
        long currentTimeMillis = System.currentTimeMillis();
        long totalSeconds = currentTimeMillis / 1000;
        setSecond((int) (totalSeconds % 60));
        long totalMinutes = totalSeconds / 60;
        setMinute((int) (totalMinutes % 60));
        long totalHours = totalMinutes / 60;
        setHour((int) (totalHours % 12));
    }
}
