import java.io.*;
import java.util.Scanner;

public class FileEncryptionDecryption {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Encrypt or Decrypt? ");
            String choice = scanner.nextLine().toLowerCase();

            if (choice.equals("encrypt")) {
                processFile(true);
            } else if (choice.equals("decrypt")) {
                processFile(false);
            } else {
                System.out.println("Invalid choice. Please enter Encrypt or Decrypt.");
            }
        }
    }

    private static void processFile(boolean encrypt) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter input file name: ");
            String inputFileName = scanner.nextLine();
            File inputFile = new File(inputFileName);

            if (!inputFile.exists()) {
                System.out.println("File not found: " + inputFileName);
                return;
            }

            System.out.print("Enter output file name: ");
            String outputFileName = scanner.nextLine();

            try (FileInputStream inputStream = new FileInputStream(inputFileName);
                 FileOutputStream outputStream = new FileOutputStream(outputFileName)) {

                int modifier = encrypt ? 5 : -5;
                int data;
                while ((data = inputStream.read()) != -1) {
                    outputStream.write(data + modifier);
                }

                System.out.println((encrypt ? "Encryption" : "Decryption") + " completed successfully.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
